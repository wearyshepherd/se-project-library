# Project 1: Practicum Library

The Practicum Library webpage is the first project in the Software Engineer program at Practicum. It was created using HTML and CSS, based on a design brief.

## Project features

- Semantic HTML5
- Flexbox
- Positioning
- Vertical stacking with z-index
